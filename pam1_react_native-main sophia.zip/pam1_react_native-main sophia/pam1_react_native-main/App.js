import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, ImageBackground } from 'react-native';


export default function App() {
  return (
    <View style={styles.container}>
      <Text>Agenda de Alunos</Text>
      <View style={styles.tarefas}>
           <Text style={styles.text}>
                   Sophia Barcelos <br></br> 
                   E-MAIL: sophiaferrerabarcelos159@gmail.com <br></br>
                   TELEFONE: (11) 96321-2451 <br></br> 
                   IDADE: 16 anos <br></br>
          </Text>
      </View>
      <View  style={styles.tarefas}>
           <Text style={styles.text}>
           <br></br>FORMAÇÃO:<br></br> 
           Cursando ensino médio com técnico em desenvolvimento de sistemas<br></br>
          </Text>
      </View>
      <View  style={styles.tarefas}>
           <Text style={styles.text}>
               SOBRE MIM:: <br></br> 
                Me chamo Sophia Barcelos, sou uma adolescente de 16 anos de idade, <br></br>  
               cursando o ensino médio com técnico em desenvolvimento de sistemas. <br></br>
               Sou uma pessoa fácil de se adpitar à lugares, trablho em grupo, <br></br>
               Falo libras e um inglês parcialmente ambos. Tenho interesse em agregar para a empresa e crescer junto com ela<br></br>
            </Text>
      </View>
       
    
    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    display: 'flex',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '120%',
   
  },  
  fundo:{
    height: '100%',
    width: '100%', 
    display: 'flex',
    justifyContent: 'center',
    position: 'absolute'
  },
  tinyLogo: {
    width: 50,
    height: 50,
    borderRadius: '25%',
    shadowColor:  '60px -16px teal;'
  },
  tarefas:{
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '60%',
    gap: '20px', 
    marginTop: '10px',
    border: 'solid black 1px',
    padding: '10px',
    paddingLeft: '30px',
    paddingRight: '30px',
    borderRadius: '10px'
  }, 
  text:{
     width: '50%',
     fontSize: '10px',
     textAlign: 'justify'
  }
});
